#warning "Xeviestr.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/evieproto.h> for the protocol defines."
#include <X11/extensions/evieproto.h>
