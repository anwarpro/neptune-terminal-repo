if [ ! -f /data/data/learn.programming.courses/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/learn.programming.courses/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/learn.programming.courses/files/home/.termux
cp /data/data/learn.programming.courses/files/usr/share/examples/termux/termux.properties /data/data/learn.programming.courses/files/home/.termux/
fi
