#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/learn.programming.courses/files/usr/lib"
XSLT_LIBS="-lxslt -L/data/data/learn.programming.courses/files/usr/lib -lxml2 "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/data/data/learn.programming.courses/files/usr/include"
MODULE_VERSION="xslt-1.1.37"
